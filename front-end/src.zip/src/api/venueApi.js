import { buildApiUrl, getAuthHeaders } from '../config/apiConfig';

/**
 * Create a new venue.
 * @returns {Promise<object>} - Created venue object.
 * @param venueJsonData
 * @param imageFiles
 */
export async function createVenue(venueJsonData, imageFiles) {
  const url = buildApiUrl("/v1/venues/create");
  const formData = new FormData();
  formData.append('venue', new Blob([JSON.stringify(venueJsonData)], {
    type: 'application/json'
  }));
  // FIX: Handle case where imageFiles is undefined or empty
  if (imageFiles && imageFiles.length > 0) {
    // Append each image file with key "images"
    imageFiles.forEach(file => {
      formData.append('images', file);
    });
  } else {
    // Append empty array if no images
    formData.append('images', new Blob([], { type: 'application/json' }));
  }
  const headers = getAuthHeaders();
  delete headers['Content-Type'];
  const response = await fetch(url, {
    method: "POST",
    headers: headers,
    body: formData,
  });

  if (!response.ok) {
    const txt = await response.text().catch(() => "");
    throw new Error(`Failed to create venue: ${response.status} ${response.statusText} ${txt}`);
  }
  return await response.json();
}


/**
 * Get a single venue by ID.
 * @returns {Promise<object>} - Venue object.
 * @param venueId
 */
export async function getVenueById(venueId) {
  const url = buildApiUrl(`/v1/venues/${encodeURIComponent(venueId)}`);
  const response = await fetch(url, {
    method: "GET",
    headers: getAuthHeaders(true),
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch venue: ${response.statusText}`);
  }

  return await response.json();
}

/**
 * Update an existing venue by ID.
 * @returns {Promise<object>} - Updated venue object.
 * @param venueId
 * @param formData
 */
export async function updateVenue(venueId, formData) {
  const url = buildApiUrl(`/v1/venues/${venueId}`);

  const headers = getAuthHeaders();
  delete headers['Content-Type']; // Let browser set multipart content type

  const response = await fetch(url, {
    method: "PUT",
    headers: headers,
    body: formData,
  });

  if (!response.ok) {
    const txt = await response.text().catch(() => "");
    throw new Error(`Failed to update venue: ${response.status} ${response.statusText} ${txt}`);
  }
  return await response.json();
}

/**
 * Delete a venue by ID.
 * @param {number|string} id - Venue ID.
 * @returns {Promise<void>} - Resolves if successful.
 */
export async function deleteVenue(id) {
  const url = buildApiUrl(`/v1/venues/${id}`);
  const response = await fetch(url, {
    method: "DELETE",
    headers: getAuthHeaders(true),
  });

  if (!response.ok) {
    throw new Error(`Failed to delete venue: ${response.statusText}`);
  }
}

/**
 * Get all venues for the venue provider.
 * @returns {Promise<Array>} - Array of venue objects.
 */

function unwrapApiData(json) {
  if (Array.isArray(json)) return json;
  if (json && Array.isArray(json.data)) return json.data;
  if (json && Array.isArray(json.content)) return json.content;
  if (json && json.data && Array.isArray(json.data.content)) return json.data.content;
  return [];
}

export async function getAllVenues() {
  const url = buildApiUrl("/v1/venues/all");
  const response = await fetch(url, { method: "GET", headers: getAuthHeaders(true) });
  if (!response.ok) throw new Error(`Failed to fetch venues: ${response.status} ${response.statusText}`);

  const json = await response.json();
  return Array.isArray(json) ? json : (json.content ?? []);
}

//
// /**
//  * Cancel a booking as a venue provider.
//  * @param {number|string} bookingId - Booking ID.
//  * @returns {Promise<void>} - Resolves if successful.
//  */
// export async function cancelVenueBooking(bookingId) {
//   const url = buildApiUrl(`/v1/venues/bookings/${bookingId}/cancel`);
//   const response = await fetch(url, {
//     method: "POST",
//     headers: getAuthHeaders(true),
//   });
//
//   if (!response.ok) {
//     throw new Error(`Failed to cancel booking: ${response.statusText}`);
//   }
// }

/**
 * Accept or reject a venue booking request.
 * @param {number|string} bookingId - Booking request ID.
 * @param {string} status - Status to set ("ACCEPTED" or "REJECTED").
 * @param {string} [reason] - Optional reason for rejection.
 * @returns {Promise<object>} - Updated booking object.
 */
export async function respondToVenueBookingRequest(bookingId, status, reason = "") {
  const url = buildApiUrl(`/v1/venues/bookings/${bookingId}/status`);
  const requestBody = { status };
  
  // Add reason if provided and status is REJECTED
  if (status === "REJECTED" && reason) {
    requestBody.cancellationReason = reason;
  }

  const response = await fetch(url, {
    method: "POST",
    headers: getAuthHeaders(true),
    body: JSON.stringify(requestBody),
  });

  if (!response.ok) {
    throw new Error(`Failed to ${status.toLowerCase()} venue booking: ${response.statusText}`);
  }

  return await response.json();
}
/**
 * Get all bookings for a venue provider.
 * @param {string} venueProviderId - Current venue provider's ID.
 * @param {number} page - Page number (optional, default 0).
 * @param {number} size - Page size (optional, default 20).
 * @returns {Promise<object>} - Paginated booking data.
 */
export async function getBookingsByVenueProviderId(venueProviderId, page = 0, size = 20) {
  const url = buildApiUrl(`/v1/bookings/venues/venue-provider/${encodeURIComponent(venueProviderId)}?page=${page}&size=${size}`);
  const response = await fetch(url, {
    method: "GET", headers: getAuthHeaders(true) });

  if (!response.ok) {
    throw new Error(`Failed to fetch bookings: ${response.statusText}`);
  }

  const json = await response.json();
  return json;
}


